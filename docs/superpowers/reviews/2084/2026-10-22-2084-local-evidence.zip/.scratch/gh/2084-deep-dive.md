### Evidence and scope

Full CI run 39802814237 at db3b1bd56f56b3ec2a439f5b3b8f47a1ee4f36aa, integration group 3/3 job 119907962917, reports status exit 1 at isolation.test.mjs:155 with a compact invalid-catalog message. The retained rehearsal CLI matrix fails through the same case. CI setup identifies Ubuntu / Node 24.22.1. Local shell currently identifies Node 26.8.1; prior package-exec probes are not Node 24 evidence. Root cause remains unknown. No product change or test execution has occurred in this worker.

Source inspection: sandbox.mjs grants read access to package scripts, bin, config, skill, guidance, instructions, docs, package.json, and individual installed dependency directories. It deliberately excludes the broad package root and node_modules root to protect production authority reached through the self-link. guidance/source.mjs selects and verifies package identity and release manifest; cache-identity.mjs observes source identity before compilation. guidance/documentation.mjs resolves packageRoot itself before resolving an allowed documentation path. Hypothesis only: supported-runtime permission semantics could refuse that package-root observation even while child documentation paths are readable. Other hypotheses are dependency resolution or cache/source identity observation. Obtain the actual public validation code inside the unmodified recorded boundary before selecting any fix.

### Story Intent

- **Beneficiary:** delivery maintainer
- **Capability:** rehearse native commands within the recorded isolation boundary
- **Need:** CI refuses the installed guidance catalog before exercising the dispatcher
- **Value or failure prevented:** compatibility checks can execute while production data and network effects remain protected

### Semantic review

All seven questions reviewed against current Scope, ACs, User Story, source, and CI evidence: (1) delivery maintainer is a real operational beneficiary; (2) capability is isolated native command rehearsal; (3) need names the concrete CI admission failure; (4) value is compatibility execution with protected production effects; (5) every claim is grounded in current issue and inspected source; (6) this differs from the separately owned archive-residue test repair and wave-10 forecast product work; (7) the three-line story is readable without a plan. No governed plan is linked, so this current deep dive supplies authoritative Story Intent.

### Owned diagnostic and regression files

Primary candidate: scripts/tests/helpers/evidence-v2/sandbox.mjs. Diagnostic transport candidate, only if necessary: scripts/tests/helpers/evidence-v2/process-bootstrap.mjs. Regression owners: scripts/tests/integration/task-tracker/lib/evidence-v2/isolation.test.mjs and scripts/tests/integration/task-tracker/lib/evidence-v2/rehearsal-cli.test.mjs. Read-only investigation includes guidance/source.mjs, guidance/cache.mjs, guidance/cache-identity.mjs, guidance/documentation.mjs, and scripts/task-tracker/guidance.mjs. Any production guidance edit requires controller scope reassessment before editing. Do not touch immutable archives or the separately owned archive-residue allowlist.

### Diagnostic and implementation sequence

1. After native Develop admission and controller GO, use the existing sandbox command/probe to run public guidance validate --published --json when status fails; preserve stdout, stderr, exit status, runtime process.version/process.execPath, and catalog source identity in project scratch. Do not broaden permissions, suppress admission, or reroute a refused runtime invocation.
2. Establish one reproducible refusal code and source path on the supported CI runtime. If local runtime differs, label local evidence accordingly and use exact-head CI for supported-runtime proof. Keep the original failure as the red baseline.
3. Form one source-grounded hypothesis from the diagnostic. If the correction crosses production guidance ownership, stop for controller reassessment. Otherwise implement the smallest sandbox/helper repair preserving production filesystem denial, arbitrary-process denial, network denial, private recorded transport, and source identity.
4. Add focused regression coverage in isolation.test.mjs for valid catalog/status success and actual invalid-catalog diagnostic/fail-closed behavior. Retain production source/private-config refusal checks. The existing rehearsal-cli.test.mjs matrix must pass without reducing cases or rewriting raw evidence.
5. Run the root-declared focused verifier, full integration, fast/slow, lint, and format checks in the admitted implementation phase; record exact runtime and exact-head CI separately. Commit only owned changes attributed to #2084, then report to controller. Agent does not advance Test/Review/Close or deliver.

### Sizing and risks

Local bottom-up S / 3.5h: 0.75h tracing, 0.75h diagnostics/reproduction, 1h minimal regression-protected correction, 1h verification/evidence. No historical task corpus, rubric, calibration, comparables, or adaptive discovery used; actual config estimationRubricIssue is 0. Root-cause uncertainty may require controller reassessment rather than permission expansion. Node 26 local success cannot establish Node 24 repair. The native event-field repair set missing Start time to 2026-10-22 10:50:15 -05:00, the actual repair time, not the earlier Refine-entry time.

### Dependency Map

Depends on: none for diagnostic admission; supported-runtime evidence remains required before claiming repair.
Blocks: #2039 full applicable CI and native Test readiness.
Sibling sub-issues to spawn: none. This standalone prerequisite does not change the epic's 32 direct children.

### Controller-approved source scope reassessment

Official Node24.22.1 security release and commit8dc18a6218 add an upfront permission check to realpathSync. Existing CI on24.22.1 failed correct published catalog with25 documentation-path-missing errors; unchanged diagnostic2 passed only on24.21.0. Existing sandbox denies package-root reads but permits shipped guidance/documents. Local Node26 stricter-native-API reproduction proves original resolver returns documentation-path-missing because its package-root observation is denied, despite permitted target documents. No security rollback or permission expansion is allowed.

Controller admits guidance/documentation.mjs: exact own running-module package-root string may derive canonical boundary from realpath of the actual permitted documentation.mjs module file, then its two parent directories. Other caller roots, aliases, trailing forms and symlink-parent/.. forms retain strict realpath(packageRoot), without lexical fallback. Canonical target containment, file check and anchors stay unchanged. Add existing guidance-documentation integration security cases, strict-native isolation regression and invalid-catalog dispatcher case. Controller also admits only check-latest:true on the existing fast-tests setup-node24 step so current patched Node24 reaches all unit/integration groups. All other workflow settings, budgets, thresholds and runtime trust remain unchanged. The actual3.5hour allocation and whole-hour4 wire representation remain distinct.
