import {createSandbox} from '../../../scripts/tests/helpers/evidence-v2/sandbox.mjs';
const sandbox=createSandbox();
try {
 console.log(JSON.stringify(sandbox.probe(`
 import {realpathSync,readFileSync,lstatSync} from 'node:fs';
 const root=${JSON.stringify(process.cwd())};
 const document=root+'/docs/guides/workflow.md';
 const observe=(name,fn)=>{try{return {name,ok:true,result:fn()};}catch(e){return {name,ok:false,code:e.code,message:e.message,syscall:e.syscall,path:e.path,resource:e.resource,permission:e.permission};}};
 console.log(JSON.stringify({runtime:{version:process.version,execPath:process.execPath},permission:{root:process.permission.has('fs.read',root),document:process.permission.has('fs.read',document)},observations:[observe('root-realpath',()=>realpathSync(root)),observe('document-realpath',()=>realpathSync(document)),observe('document-read',()=>readFileSync(document,'utf8').length),observe('root-lstat',()=>lstatSync(root).isDirectory())]}));
 `),null,2));
}finally{sandbox.dispose();}
