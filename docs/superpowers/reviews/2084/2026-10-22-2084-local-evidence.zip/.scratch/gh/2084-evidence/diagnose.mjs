import { createSandbox } from '../../../scripts/tests/helpers/evidence-v2/sandbox.mjs';
const sandbox = createSandbox();
try {
  console.log(JSON.stringify({outerRuntime:{version:process.version,execPath:process.execPath},status:sandbox.command(['status']),validation:sandbox.command(['guidance','validate','--published','--json']),source:sandbox.command(['guidance','source','--json']),probe:sandbox.probe(`import {loadGuidance} from ${JSON.stringify(new URL('../../../guidance/cache.mjs',import.meta.url).href)};console.log(JSON.stringify({runtime:{version:process.version,execPath:process.execPath},loaded:loadGuidance({need:'diagnostics',publishedOnly:true})}));`)},null,2));
} finally {sandbox.dispose();}
