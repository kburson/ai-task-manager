import {createSandbox} from '../../../scripts/tests/helpers/evidence-v2/sandbox.mjs';
const sandbox=createSandbox();
try {
 const result=sandbox.probe(`
 import assert from 'node:assert/strict';
 import fs from 'node:fs';
 import {syncBuiltinESMExports} from 'node:module';
 import path from 'node:path';
 const root=${JSON.stringify(process.cwd())};
 const document=path.join(root,'docs','guides','workflow.md');
 const native=fs.realpathSync.native;
 console.log(JSON.stringify({runtime:{version:process.version,execPath:process.execPath},rootPermission:process.permission.has('fs.read',root),documentPermission:process.permission.has('fs.read',document)}));
 assert.equal(process.permission.has('fs.read',root),false);
 assert.equal(process.permission.has('fs.read',document),true);
 assert.throws(()=>native(root),{code:'ERR_ACCESS_DENIED'});
 fs.realpathSync=Object.assign((...args)=>native(...args),{native});
 syncBuiltinESMExports();
 const {resolveDocumentationReference}=await import(${JSON.stringify(new URL('../../../guidance/documentation.mjs',import.meta.url).href)});
 const resolved=resolveDocumentationReference({path:'docs/guides/workflow.md'},{packageRoot:root});
 console.log(JSON.stringify({resolved}));
 assert.equal(resolved.ok,true,'shipped document must resolve under the native enforced permission boundary');
 `);
 console.log(JSON.stringify(result,null,2));
 process.exitCode=result.exitCode;
}finally{sandbox.dispose();}
